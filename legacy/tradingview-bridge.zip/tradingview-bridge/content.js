// TradingView Bridge - Connects position tool to Hyperliquid Trader
// This script watches for Long/Short Position dialogs and sends data to the local app

const BRIDGE_PORT = 3456;
const BRIDGE_URL = `http://localhost:${BRIDGE_PORT}/position`;

let lastSentData = null;
let debounceTimer = null;

// Extract position data from the dialog
function extractPositionData(dialog) {
  // Get dialog name directly from the element's attribute
  const dialogName = dialog.getAttribute('data-dialog-name');
  if (!dialogName) {
    console.log('[TV Bridge] No dialog name found');
    return null;
  }

  console.log('[TV Bridge] Found dialog:', dialogName);

  const isLong = dialogName.toLowerCase().includes('long');
  const isShort = dialogName.toLowerCase().includes('short');
  if (!isLong && !isShort) {
    console.log('[TV Bridge] Not a position dialog');
    return null;
  }

  const prefix = isLong ? 'long' : 'short';

  // Get values from inputs using data-property-id
  const getValue = (propId) => {
    const selector = `input[data-property-id="Risk/Reward${prefix}${propId}"]`;
    const input = dialog.querySelector(selector);
    if (!input) {
      console.log('[TV Bridge] Input not found:', selector);
      return null;
    }
    const value = parseFloat(input.value.replace(/,/g, ''));
    console.log('[TV Bridge] Found', propId, '=', value);
    return value;
  };

  const entry = getValue('EntryPrice');
  const tp = getValue('ProfitLevelPrice');
  const sl = getValue('StopLevelPrice');

  if (!entry || !sl) {
    console.log('[TV Bridge] Missing entry or stop loss');
    return null;
  }

  return {
    direction: isLong ? 'long' : 'short',
    entry,
    stopLoss: sl,
    takeProfit: tp,
    timestamp: Date.now()
  };
}

// Send data to Tauri app
async function sendToApp(data) {
  // Debounce to avoid spamming
  if (debounceTimer) clearTimeout(debounceTimer);

  debounceTimer = setTimeout(async () => {
    // Don't send if data hasn't changed
    const dataStr = JSON.stringify(data);
    if (dataStr === lastSentData) return;
    lastSentData = dataStr;

    try {
      await fetch(BRIDGE_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: dataStr
      });
      console.log('[TV Bridge] Sent position data:', data);
    } catch (e) {
      // App not running, silently ignore
      console.log('[TV Bridge] App not connected');
    }
  }, 100);
}

// Watch for position dialogs
function watchForDialogs() {
  console.log('[TV Bridge] Starting to watch for dialogs...');

  const checkForDialog = () => {
    // Look for position dialog - the data-dialog-name is on the inner div with role="dialog"
    const dialog = document.querySelector('[data-dialog-name="Long Position"], [data-dialog-name="Short Position"]');

    if (dialog) {
      console.log('[TV Bridge] Dialog detected!');
      const data = extractPositionData(dialog);
      if (data) {
        sendToApp(data);

        // Also watch for changes within the dialog
        observeDialog(dialog);
      }
    } else {
      // Dialog closed - notify app
      if (lastSentData) {
        console.log('[TV Bridge] Dialog closed, notifying app');
        fetch(`http://localhost:${BRIDGE_PORT}/position-closed`, { method: 'POST' }).catch(() => {});
        lastSentData = null;
      }
    }
  };

  const observer = new MutationObserver((mutations) => {
    checkForDialog();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  // Also check immediately in case dialog is already open
  checkForDialog();
}

// Watch for value changes within the dialog
let dialogObserver = null;
function observeDialog(dialog) {
  if (dialogObserver) dialogObserver.disconnect();

  dialogObserver = new MutationObserver(() => {
    const data = extractPositionData(dialog);
    if (data) sendToApp(data);
  });

  // Watch input values
  dialog.querySelectorAll('input').forEach(input => {
    input.addEventListener('input', () => {
      const data = extractPositionData(dialog);
      if (data) sendToApp(data);
    });
    input.addEventListener('change', () => {
      const data = extractPositionData(dialog);
      if (data) sendToApp(data);
    });
  });

  dialogObserver.observe(dialog, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['value']
  });
}

// Start watching when page loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', watchForDialogs);
} else {
  watchForDialogs();
}

console.log('[TV Bridge] TradingView Bridge loaded');
